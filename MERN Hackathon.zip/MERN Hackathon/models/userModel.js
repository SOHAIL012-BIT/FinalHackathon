const mongoose = require('mongoose')


const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        trim: true
    },
    fname:{
        type: String,
        required: true,
        trim: true
    },
   CNIC:{
        type: String,
        required: true,
        trim: true
    },
    DOB:{
        type: String,
        required: true,
        trim: true
    },
    contact:{
        type: String,
        required: true,
        trim: true
    },
    noofFamilyMember:{
        type: String,   
        required: true,
        trim: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    }
}, {
    timestamps: true
})

module.exports = mongoose.model('Users', userSchema)