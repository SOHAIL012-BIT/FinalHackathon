const Managers = require('../models/ManagerModel')


const ManagerCtrl = {
    getManagers: async (req, res) =>{
        try {
            const Managers = await Managers.find({user_id: req.user.id})
            res.json(Managers)
        } catch (err) {
            return res.status(500).json({msg: err.message})
        }
    },
    createManager: async(req, res) =>{
        try {
            const {name,email,date,password} = req.body;
            const newManager = new Managers({
                name,
                email,
                date,
                password,
                user_id: req.user.id,
                name: req.user.name
            })
            await newManager.save()
            res.json({msg: "Created a Manager"})
        } catch (err) {
            return res.status(500).json({msg: err.message})
        }
    },
    deleteManager: async(req, res) =>{
        try {
            await Managers.findByIdAndDelete(req.params.id)
            res.json({msg: "Deleted a Manager"})
        } catch (err) {
            return res.status(500).json({msg: err.message})
        }
    },
    updateManager: async(req, res) =>{
        try {
            const {name,email,date,password} = req.body;
            await Managers.findOneAndUpdate({_id: req.params.id},{
                name,
                email,
                date,
                password
            })
            res.json({msg: "Updated a Manager"})
        } catch (err) {
            return res.status(500).json({msg: err.message})
        }
    },
    getManager: async(req, res) => {
        try {
            const Manager = await Managers.findById(req.params.id)
            res.json(Manager)
        } catch (err) {
            return res.status(500).json({msg: err.message})
        }
    }
}

module.exports = ManagerCtrl