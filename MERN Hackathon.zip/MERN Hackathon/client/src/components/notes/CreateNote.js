import React, {useState} from 'react'
import axios from 'axios'
import {useHistory} from 'react-router-dom'

export default function CreateNote() {
    const [note, setNote] = useState({
        title: '',
        password: '',
        date: ''
    })
    const history = useHistory()

    const onChangeInput = e => {
        const {name, value} = e.target;
        setNote({...note, [name]:value})
    }


    const createNote = async e => {
        e.preventDefault()
        try {
            const token = localStorage.getItem('tokenStore')
            if(token){
                const {title, password, date} = note;
                const newNote = {
                    title, password, date
                }

                await axios.post('/api/notes', newNote, {
                    headers: {Authorization: token}
                })
                
                return history.push('/')
            }
        } catch (err) {
            window.location.href = "/";
        }
    }

    return (
        <div className="create-note">
            <h2>ADD MANAGER</h2>
            <form onSubmit={createNote} autoComplete="off">
                
                <div className="row">
                    <label htmlFor="title">MANAGER NAME</label>
                    <input type="text" value={note.title} id="title"
                    name="title" required onChange={onChangeInput} />
                </div>



                <div className="row">
                    <label htmlFor="title">EMAIL</label>
                    <input type="email" value={note.title} id="email"
                    name="title" required onChange={onChangeInput} />
                </div>

                <div className="row">
                    <label htmlFor="password">Password</label>
                    <textarea type="password" value={note.password} id="password"
                    name="password" onChange={onChangeInput} />
                </div>

                <label htmlFor="date">Date of Application: {note.date} </label>
                <div className="row">
                    <input type="date" id="date"
                    name="date" onChange={onChangeInput} />
                </div>

                <button type="submit">Send Application</button>
            </form>
        </div>
    )
}
