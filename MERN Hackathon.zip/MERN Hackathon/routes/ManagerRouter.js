const router = require('express').Router()
const auth = require('../middleware/auth')
const ManagerCtrl = require('../controllers/ManagerCtrl')

router.route('/')
    .get(auth, ManagerCtrl.getManagers)
    .post(auth, ManagerCtrl.createManager)

router.route('/:id')
    .get(auth, ManagerCtrl.getManager)
    .put(auth, ManagerCtrl.updateManager)
    .delete(auth, ManagerCtrl.deleteManager)


module.exports = router