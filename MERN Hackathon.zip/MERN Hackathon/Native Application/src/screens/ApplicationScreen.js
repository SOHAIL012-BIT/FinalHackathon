import React, { useState } from 'react'
import { View, StyleSheet, TouchableOpacity } from 'react-native'
import { Text } from 'react-native-paper'
import Background from '../components/Background'
import Logo from '../components/Logo'
import Header from '../components/Header'
import Button from '../components/Button'
import TextInput from '../components/TextInput'
import BackButton from '../components/BackButton'
import { theme } from '../core/theme'
import { nameValidator } from '../helpers/nameValidator'

export default function ApplicationScreen({ navigation }) {
  const [name, setName] = useState({ value: '', error: '' })
  const [fname, setFName] = useState({ value: '', error: '' })
  const [cnic, setcnic] = useState({ value: '', error: '' })
  const [dob, setdob] = useState({ value: '', error: '' })
  const [noOfFamily, setnoOfFamily] = useState({ value: '', error: '' })
  const onSignUpPressed = () => {
    // const nameError = nameValidator(name.value)
    // if (emailError || passwordError || nameError) {
    //   setName({ ...name, error: nameError })
    //   return
    // }
    // navigation.reset({
    //   index: 0,
    //   routes: [{ name: 'Dashboard' }],
    // })
    alert("Application Sent")
  }

  return (
    <Background>
      <BackButton goBack={navigation.goBack} />
      <Logo />
      <Header>Create Application Here</Header>
      <TextInput
        label="Name"
        returnKeyType="next"
        value={name.value}
        onChangeText={(text) => setName({ value: text, error: '' })}
        error={!!name.error}
        errorText={name.error}
      />
      <TextInput
        label=" Father Name"
        returnKeyType="next"
        value={fname.value}
        onChangeText={(text) => setFName({ value: text, error: '' })}
        error={!!name.error}
        errorText={name.error}
      />
      <TextInput
        label="CNIC"
        returnKeyType="next"
        value={cnic.value}
        onChangeText={(text) => setcnic({ value: text, error: '' })}
        error={!!name.error}
        errorText={name.error}
      />
       <TextInput
        label="Date Of Birth"
        returnKeyType="next"
        value={dob.value}
        onChangeText={(text) => setdob({ value: text, error: '' })}
        error={!!name.error}
        errorText={name.error}
      />
       <TextInput
        label="NO OF FAMILY MEMBERS"
        returnKeyType="next"
        value={noOfFamily.value}
        onChangeText={(text) => setnoOfFamily({ value: text, error: '' })}
        error={!!name.error}
        errorText={name.error}
      />
     <Button
        mode="outlined"
        onPress={() => navigation.navigate('DropdownComponent')}
      >
        Next Step
      </Button>
     
    </Background>
  )
}

const styles = StyleSheet.create({
  
})
