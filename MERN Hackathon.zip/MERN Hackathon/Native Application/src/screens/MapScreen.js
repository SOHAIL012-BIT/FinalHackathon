import React from "react";
import { StyleSheet, Text, View } from "react-native";
import MapView from "react-native-maps";
import BackButton from '../components/BackButton'

export default function MapScreen({ navigation }) {
  return (
    
    <View style={styles.container}>
    <BackButton goBack={navigation.goBack} />
      <MapView
        style={styles.map}
        //specify our coordinates.
        initialRegion={{
          latitude:  24.8732834,
          longitude:  67.0337457,
        }
        }
      />
    </View>
  );
}
//create our styling code:
const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    flex: 1, //the container will fill the whole screen.
    justifyContent: "flex-end",
    alignItems: "center",
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
});