import QRCode from 'react-native-qrcode-svg';
import React, { useState } from 'react'
import Background from '../components/Background'
import Logo from '../components/Logo'
import Header from '../components/Header'
import BackButton from '../components/BackButton'
import { theme } from '../core/theme'


export default function QRCodeScreen({ navigation }) {
  return (
    <Background>
      <BackButton goBack={navigation.goBack} />
      <Logo />
      <Header>SCAN THIS!!</Header>
    <QRCode
      value="12345"
    />
    </Background>
  )
  }