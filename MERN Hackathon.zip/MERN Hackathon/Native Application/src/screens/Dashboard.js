import React from 'react'
import Background from '../components/Background'
import Logo from '../components/Logo'
import Header from '../components/Header'
import Paragraph from '../components/Paragraph'
import Button from '../components/Button'

export default function Dashboard({ navigation }) {
  return (
    <Background>
      <Logo />
      <Header>Find Nearest Branch of Saylani</Header>
      <Paragraph>
        You can search your nearest Branch and visit for further help.
      </Paragraph>
      <Button
        mode="outlined"
        onPress={() => navigation.navigate('ApplicationScreen')}
      >
        Add Application
      </Button>
       <Button
        mode="outlined"
        onPress={() => navigation.navigate('QRCodeScreen')}
      >
        Open QR CODE
      </Button>
      <Button
        mode="outlined"
        onPress={() =>
          navigation.reset({
            index: 0,
            routes: [{ name: 'MapScreen' }],
          })
        }
      >
        Go TO MAP
      </Button>
    </Background>
  )
}
