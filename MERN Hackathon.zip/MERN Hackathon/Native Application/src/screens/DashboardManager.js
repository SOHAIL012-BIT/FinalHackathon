import React, { useState } from 'react'
import Background from '../components/Background'
import { View, StyleSheet, TouchableOpacity } from 'react-native'
import Logo from '../components/Logo'
import Header from '../components/Header'
import Paragraph from '../components/Paragraph'
import Button from '../components/Button'
import TextInput from '../components/TextInput'
import { theme } from '../core/theme'
import { Text } from 'react-native-paper'

export default function DashboardManager({ navigation }) {
  
    const [ID, setID] = useState({ value: '', error: '' })

     const onIDPressed = () => {
    // const nameError = nameValidator(name.value)
    // if (emailError || passwordError || nameError) {
    //   setName({ ...name, error: nameError })
    //   return
    // }
    // navigation.reset({
    //   index: 0,
    //   routes: [{ name: 'Dashboard' }],
    // })
    alert("ID Verified")
  }
  return (

    <Background>
      <Logo />
      <Header>Wellcome Branch Manager</Header>
      <Paragraph>
        You can verify Help Application here.
      </Paragraph>
      <Paragraph>
      Search BY ID
      </Paragraph>
      <TextInput
        label="Search By ID"
        returnKeyType="next"
        value={ID.value}
        onChangeText={(text) => setID({ value: text, error: '' })}
        error={!!ID.error}
        errorText={ID.error}
      /> 
      <Button
        mode="contained"
        onPress={onIDPressed}
        style={{ marginTop: 24 }}
      >
        Search
      </Button>
      <View style={styles.row}>
      </View>

       <Button
        mode="outlined"
        onPress={() => navigation.navigate('ScannerScreen')}
      >
        SCAN QR CODE
      </Button>
      <Button
        mode="outlined"
        onPress={() =>
          navigation.reset({
            index: 0,
            routes: [{ name: 'MapScreen' }],
          })
        }
      >
        Go TO MAP
      </Button>
    </Background>
  )
}
const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    marginTop: 4,
  }
})
