import React from 'react';
import { Provider } from 'react-native-paper';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { theme } from './src/core/theme';
import {
  StartScreen,
  LoginScreen,
  RegisterScreen,
  MapScreen,
  ResetPasswordScreen,
  Dashboard,
  ApplicationScreen,
  QRCodeScreen,
  LoginScreenManager,
  DashboardManager,
  QRCodeScannerScreen,
DropdownComponent
} from './src/screens';

const Stack = createStackNavigator();

export default function App() {
  return (
    <Provider theme={theme}>
      <NavigationContainer>
        <Stack.Navigator
          initialRouteName="StartScreen"
          screenOptions={{
            headerShown: false,
          }}>
          <Stack.Screen name="StartScreen" component={StartScreen} />
          <Stack.Screen name="LoginScreen" component={LoginScreen} />
          <Stack.Screen name="RegisterScreen" component={RegisterScreen} />
          <Stack.Screen name="Dashboard" component={Dashboard} />
          <Stack.Screen name="ApplicationScreen" component={ApplicationScreen}/>
          <Stack.Screen name="MapScreen" component={MapScreen} />
          <Stack.Screen name="QRCodeScreen" component={QRCodeScreen} />
          <Stack.Screen name="LoginScreenManager" component={LoginScreenManager}/>
          <Stack.Screen name="DashboardManager" component={DashboardManager}/>
          <Stack.Screen name="QRCodeScannerScreen" component={QRCodeScannerScreen}/>
           <Stack.Screen name="DropdownComponent" component={DropdownComponent}/>

          
          <Stack.Screen
            name="ResetPasswordScreen"
            component={ResetPasswordScreen}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </Provider>
  );
}
